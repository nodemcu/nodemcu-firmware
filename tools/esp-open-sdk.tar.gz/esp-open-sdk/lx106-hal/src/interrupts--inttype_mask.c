#define __SPLIT__inttype_mask
#include "interrupts.c"
