#define __SPLIT__vpri_int_enable
#include "interrupts.c"
