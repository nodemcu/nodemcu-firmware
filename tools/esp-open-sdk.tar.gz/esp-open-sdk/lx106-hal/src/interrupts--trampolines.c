#define __SPLIT__trampolines
#include "interrupts.c"
