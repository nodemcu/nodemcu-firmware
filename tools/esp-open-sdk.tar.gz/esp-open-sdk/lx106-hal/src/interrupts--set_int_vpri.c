#define __SPLIT__set_int_vpri
#include "interrupts.c"
