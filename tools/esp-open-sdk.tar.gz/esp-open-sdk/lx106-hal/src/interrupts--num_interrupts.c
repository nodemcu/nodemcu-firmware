#define __SPLIT__num_interrupts
#include "interrupts.c"
