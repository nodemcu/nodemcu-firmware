#define __SPLIT__intlevel_to_vpri
#include "interrupts.c"
