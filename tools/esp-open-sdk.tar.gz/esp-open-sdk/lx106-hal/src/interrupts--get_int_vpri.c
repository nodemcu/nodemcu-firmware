#define __SPLIT__get_int_vpri
#include "interrupts.c"
