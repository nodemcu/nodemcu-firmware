#define __SPLIT__intlevel_mask
#include "interrupts.c"
